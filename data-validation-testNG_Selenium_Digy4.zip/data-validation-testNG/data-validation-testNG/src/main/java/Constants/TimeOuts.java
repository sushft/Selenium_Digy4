package Constants;

public class TimeOuts {
	public static long DEFAULT_TIMEOUT=60;
	public static int SWITCH_WINDOW_TIMEOUT=30;

}
